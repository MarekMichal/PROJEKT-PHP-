<!DOCTYPE html>
<html>
    <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" connect="IE=edge">
      <meta name="viewport" connect="width=device-width, initial-scale=1.0">
      <title>Document</title>
    </head>
    <body>
        <a href="../index.php">Domov</a>
        <form action="php_scripts/registercode.php" method="POST">
          <label for="username">username: </label>
            <input type="text" name="username">
         <label for="username">email: </label>
          <input type="mail" name="email">
           <label for="password">password: </label>
          <input type="password" name="password">
           <label for="password_check">password verify: </label>
          <input type="password" name="password_check">
           <input type="submit">
        </form>
    </body>
</html>