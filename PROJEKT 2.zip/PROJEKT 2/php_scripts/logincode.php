<!DOCTYPE html>
<html>
    <style>
        php{background-color:orangered}
        </style>
    <body>

<?php


if ($_POST['email']=="marek" && $_POST['psw']=="123")
{echo "si prihlaseny";}
else{echo "nie sií prihlaseny";}
?>
</body>
</html>
